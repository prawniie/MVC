﻿use Mvc_02

select * from AspNetRoles
select * from AspNetUsers