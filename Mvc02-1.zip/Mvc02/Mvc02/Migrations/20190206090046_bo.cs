﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Mvc02.Migrations
{
    public partial class bo : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
