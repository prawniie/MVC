﻿use Mvc02

select * from AspNetUsers

select * from Product